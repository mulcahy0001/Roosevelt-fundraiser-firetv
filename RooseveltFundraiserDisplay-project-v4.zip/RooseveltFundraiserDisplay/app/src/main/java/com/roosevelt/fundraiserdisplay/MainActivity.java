package com.roosevelt.fundraiserdisplay;

import android.app.Activity;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebBackForwardList;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.net.URI;
import java.net.URISyntaxException;

public final class MainActivity extends Activity {
    private static final String HOME_URL =
            "https://roosevelt-hermit-crabs-pledges.mulcahy001.chatgpt.site/";
    private static final String ALLOWED_HOST =
            "roosevelt-hermit-crabs-pledges.mulcahy001.chatgpt.site";
    private static final long EXIT_CONFIRMATION_MS = 2_000L;
    private static final long[] RETRY_DELAYS_MS = {3_000L, 6_000L, 12_000L, 30_000L};

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable retryRunnable = this::loadHome;
    private WebView webView;
    private int retryAttempt;
    private volatile boolean mainFrameFailed;
    private long lastBackPressedAt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        enterImmersiveMode();
        createWebView();

        if (savedInstanceState == null) {
            loadHome();
        } else {
            WebBackForwardList restored = webView.restoreState(savedInstanceState);
            if (restored == null || restored.getSize() == 0) loadHome();
        }
    }

    private void createWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF000000);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        webView.setWebChromeClient(new FullScreenChromeClient());
        webView.setWebViewClient(new DisplayWebViewClient());

        setContentView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        webView.requestFocus();
    }

    private void loadHome() {
        if (webView == null) return;
        handler.removeCallbacks(retryRunnable);
        mainFrameFailed = false;
        webView.loadUrl(HOME_URL);
    }

    private void scheduleRetry() {
        handler.removeCallbacks(retryRunnable);
        long delay = RETRY_DELAYS_MS[Math.min(retryAttempt, RETRY_DELAYS_MS.length - 1)];
        retryAttempt++;
        handler.postDelayed(retryRunnable, delay);
    }

    private void refresh() {
        retryAttempt = 0;
        Toast.makeText(this, R.string.refreshing, Toast.LENGTH_SHORT).show();
        loadHome();
    }

    private boolean isAllowedTopLevelUrl(String url) {
        try {
            URI uri = new URI(url);
            return "https".equalsIgnoreCase(uri.getScheme())
                    && ALLOWED_HOST.equalsIgnoreCase(uri.getHost());
        } catch (URISyntaxException ignored) {
            return false;
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU && event.getRepeatCount() == 0) {
            refresh();
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE && event.getRepeatCount() == 1) {
            refresh();
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_MEDIA_REWIND && event.getRepeatCount() == 1) {
            toggleAutoStart();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
            return;
        }

        long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastBackPressedAt <= EXIT_CONFIRMATION_MS) {
            super.onBackPressed();
        } else {
            lastBackPressedAt = now;
            Toast.makeText(this, R.string.press_back_again, Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleAutoStart() {
        boolean current = getSharedPreferences(BootReceiver.PREFS, MODE_PRIVATE)
                .getBoolean(BootReceiver.AUTO_START, false);
        boolean next = !current;
        getSharedPreferences(BootReceiver.PREFS, MODE_PRIVATE).edit()
                .putBoolean(BootReceiver.AUTO_START, next).apply();
        Toast.makeText(this, next ? R.string.autostart_on : R.string.autostart_off,
                Toast.LENGTH_LONG).show();
    }

    private void enterImmersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enterImmersiveMode();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
        enterImmersiveMode();
    }

    @Override
    protected void onPause() {
        webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        webView.stopLoading();
        webView.setWebChromeClient(null);
        webView.setWebViewClient(null);
        webView.destroy();
        super.onDestroy();
    }

    private final class DisplayWebViewClient extends WebViewClient {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            if (isAllowedTopLevelUrl(url)) mainFrameFailed = false;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            if (!mainFrameFailed && isAllowedTopLevelUrl(url)) {
                retryAttempt = 0;
                handler.removeCallbacks(retryRunnable);
            }
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request,
                                    WebResourceError error) {
            if (request.isForMainFrame()) {
                mainFrameFailed = true;
                scheduleRetry();
            }
        }

        @SuppressWarnings("deprecation")
        @Override
        public void onReceivedError(WebView view, int errorCode,
                                    String description, String failingUrl) {
            if (failingUrl != null && failingUrl.equals(view.getUrl())) {
                mainFrameFailed = true;
                scheduleRetry();
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            if (!request.isForMainFrame()) return false;
            boolean blocked = !isAllowedTopLevelUrl(request.getUrl().toString());
            if (blocked) Toast.makeText(MainActivity.this, R.string.link_blocked,
                    Toast.LENGTH_SHORT).show();
            return blocked;
        }

        @SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            boolean blocked = !isAllowedTopLevelUrl(url);
            if (blocked) Toast.makeText(MainActivity.this, R.string.link_blocked,
                    Toast.LENGTH_SHORT).show();
            return blocked;
        }

    }

    private final class FullScreenChromeClient extends WebChromeClient {
        private View customView;
        private CustomViewCallback customViewCallback;

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (customView != null) {
                callback.onCustomViewHidden();
                return;
            }
            customView = view;
            customViewCallback = callback;
            setContentView(view);
            enterImmersiveMode();
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) return;
            setContentView(webView);
            customView = null;
            if (customViewCallback != null) customViewCallback.onCustomViewHidden();
            customViewCallback = null;
            enterImmersiveMode();
        }
    }
}
