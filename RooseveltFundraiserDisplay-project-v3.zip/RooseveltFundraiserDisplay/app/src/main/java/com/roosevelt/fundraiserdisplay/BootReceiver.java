package com.roosevelt.fundraiserdisplay;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Starts the display after boot only when the user has explicitly enabled the option. */
public final class BootReceiver extends BroadcastReceiver {
    static final String PREFS = "display_preferences";
    static final String AUTO_START = "auto_start_after_boot";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            return;
        }

        boolean enabled = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(AUTO_START, false);
        if (!enabled) {
            return;
        }

        Intent launch = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try {
            context.startActivity(launch);
        } catch (RuntimeException ignored) {
            // Some recent Fire OS versions prohibit boot-time foreground launches.
            // The normal launcher remains available as the fallback.
        }
    }
}
